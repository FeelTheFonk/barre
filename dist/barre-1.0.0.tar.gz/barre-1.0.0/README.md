# barre

Minimal progress bar, one line to rule them all.

```python
from barre import b

for x in b(range(100)): ...
```

Output:
```
[||||||||||||||||                    ] 123/300
```

That's all.